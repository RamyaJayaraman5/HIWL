import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AngularFireModule } from '@angular/fire';  
import{TasksService} from'./tasks.service';
import{FormsModule,ReactiveFormsModule}from '@angular/forms';
import{HttpClientModule,HttpClient} from'@angular/common/http';
import{MatButtonModule,MatMenuModule,MatDatepickerModule,MatNativeDateModule,MatIconModule,MatSidenavModule,MatInputModule,MatTooltipModule,
MatToolbarModule, MatListModule}from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import{MatFormFieldModule}from '@angular/material/form-field';
import{TasksComponent}from'./tasks/tasks.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import {MatTabsModule} from '@angular/material/tabs';
import{FormBuilder,Validators, FormGroup, FormControl}from'@angular/forms';
import { TaskFormComponent } from './task-form/task-form.component';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { CommonModule } from '@angular/common';
//import{AngularFireModule}from'angularfire2';
import{AngularFireDatabaseModule}from'angularfire2/database';
import { DatePipe } from '@angular/common';
@NgModule({
  declarations: [
    AppComponent,
    TasksComponent,
    TaskFormComponent,
  ],
  imports: [
    BrowserModule,
    
    CommonModule,
    AppRoutingModule,
    MatButtonModule,
    MatSnackBarModule,
    HttpClientModule,//very important
    MatMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatTabsModule,
    MatFormFieldModule,
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatSidenavModule,
    MatInputModule,
    MatTooltipModule,
    MatToolbarModule, 
    MatListModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFireDatabaseModule,
    AngularFireModule.initializeApp(environment.firebase),
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [HttpClientModule,TasksService,MatDatepickerModule,DatePipe],
  
  bootstrap: [AppComponent],
  entryComponents:[TasksComponent,TaskFormComponent]
})
export class AppModule { }
