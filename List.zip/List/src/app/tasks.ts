export class Tasks {
    $key:string;
    TaskDescription:string;
    Name:string;
    MobileNumber:string;
    ScheduleDate:string;
    Status:string;

}
