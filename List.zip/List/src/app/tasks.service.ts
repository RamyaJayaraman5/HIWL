import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{HttpHeaders} from'@angular/common/http';
import{Observable}from'rxjs';
import {Tasks}from './tasks';
import { DatePipe } from '@angular/common';
import { FormGroup, FormControl,Validators } from '@angular/forms';
import{AngularFireDatabase,AngularFireList}from'angularfire2/database';
import { FirebaseApp } from '@angular/fire';

@Injectable({
  providedIn: 'root'
})
export class TasksService {
  
     //added newly 
  form:FormGroup=new FormGroup({
      $key:new FormControl(''),
      Name:new FormControl('',Validators.required),
      TaskDescription:new FormControl('',Validators.required),
      MobileNumber:new FormControl('',[Validators.required,Validators.minLength(10)]),
      ScheduleDate:new FormControl(''),
      Status:new FormControl('',Validators.required)
 
});
InitializeformGroup(){
  this.form.setValue({
    $key: null,
    Name: '',
    TaskDescription: '',
    MobileNumber: '',
    ScheduleDate: '',
    Status: ''
    
  });
}

  constructor(private http:HttpClient,private firebase:AngularFireDatabase,private datePipe: DatePipe) { }
//for getting data from firebase and storing here
  tasksList:AngularFireList<any>;
  

  //added for update tasks 
  PopulateModal(Tasks){
   this.form.setValue(Tasks);
  }
  //firebase database oprations
  getTasks(){
    this.tasksList=this.firebase.list('Tasks');
  return this.tasksList.snapshotChanges();
  
  }
  
  insertTaskList(Tasks){
  this.tasksList.push({
  Name:Tasks.Name,
  //ListId:string;
  TaskDescription:Tasks.TaskDescription,
  MobileNumber:Tasks.MobileNumber,
  ScheduleDate:Tasks.ScheduleDate == "" ? "" : this.datePipe.transform(Tasks.ScheduleDate, 'yyyy-MM-dd'),
  Status:Tasks.Status
});
  }
  updateTaskList(Tasks){
    this.tasksList.update(Tasks.$key,
      {
        Name:Tasks.Name,
        TaskDescription:Tasks.TaskDescription,
        MobileNumber:Tasks.MobileNumber,
        ScheduleDate:Tasks.ScheduleDate == "" ? "" : this.datePipe.transform(Tasks.ScheduleDate, 'yyyy-MM-dd'),
        Status:Tasks.Status
      });
  }
  deleteTask($key:string){
this.tasksList.remove($key);
  }
  
}




