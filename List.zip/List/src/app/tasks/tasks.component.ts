import { Component, OnInit,ViewChild ,AfterViewInit} from '@angular/core';
import{FormBuilder,Validators, FormGroup, FormControl}from'@angular/forms';
import{Observable}from'rxjs';
import{TasksService}from'../tasks.service';
import{Tasks}from '../tasks';
import{MatDialog,MatDialogConfig,MatTableDataSource,MatPaginator,MatSort} from'@angular/material';
import{TaskFormComponent} from'../task-form/task-form.component';
import{NotificationService} from'../notification.service';
@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {
  dataSaved=false;
  CreateTasksModal:any;
  allTasks:Observable<Tasks[]>;
  allTasksList:Observable<Tasks[]>;
  taskIdUpdate=null;
  message=null;
  CountDue:string;
  CountCompleted:string;
  searchKey:string;//filter
  
 public displayedColumns:string[]= ['Name', 'TaskDescription', 'Status','ScheduleDate','actions'];
 public dataSource:MatTableDataSource<any>;
 //added {static:true} pagination,sorting
 @ViewChild(MatPaginator,{static:true}) paginator: MatPaginator; 
 @ViewChild (MatSort,{static:true}) sort: MatSort;
  
  constructor(private formbuilder:FormBuilder,
    private taskService:TasksService,
    private dialog:MatDialog,
    private notificationService:NotificationService) { }
    
  
ngOnInit() {
    
    this.taskService.getTasks().subscribe(
      list=>{
      let array=list.map(item=>{
      return{
        $key:item.key,
       ...item.payload.val()
            };
             });
             this.dataSource=new MatTableDataSource(array);
             this.dataSource.sort=this.sort;
             this.dataSource.paginator=this.paginator;
             
            });
            
           
      }//$KEY added string property
  deleteTasks($key: string){
      if(confirm("Are you sure you want to delete this task?")){
        this.taskService.deleteTask($key);
          this.notificationService.warn('! Record Deleted successfully');
      }
        }
  resetForm(){
      this.CreateTasksModal.reset();
      this.message=null;
      this.dataSaved=false;
    }
  //open form in modal popup
    OpenFormModal(){
      //added from service-initialize form group
      this.taskService.InitializeformGroup();
      const dialogConfig=new MatDialogConfig();
     //dialogConfig.disableClose=true;
      dialogConfig.autoFocus=true;
      dialogConfig.width="70%";
      this.dialog.open(TaskFormComponent,dialogConfig);
    }
    //edit task in modal popup (ROW)
    EditTask(row: any){
      this.taskService.PopulateModal(row);
      const dialogConfig=new MatDialogConfig();
     //dialogConfig.disableClose=true;
      dialogConfig.autoFocus=true;
      dialogConfig.width="70%";
      this.dialog.open(TaskFormComponent,dialogConfig);
 
    }
    onSearchClear(){
      this.searchKey="";
      this.applyFilter();
    }
    applyFilter(){
      this.dataSource.filter=this.searchKey.trim().toLowerCase();
    }
    
}

  
  
  
    