import { Component, OnInit } from '@angular/core';
import{FormBuilder,Validators, FormGroup, FormControl}from'@angular/forms';
import{Observable}from'rxjs';
import{TasksService}from'../tasks.service';
import{Tasks}from '../tasks';
import{MatDialogRef} from'@angular/material';
import{TasksComponent}from'../tasks/tasks.component';
import{NotificationService}from'../notification.service';
@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.css']
})
export class TaskFormComponent implements OnInit {
  dataSaved=false;
  CreateTasksModal:any;
  allTasks:Observable<Tasks[]>;
  allTasksList:Observable<Tasks[]>;
  taskIdUpdate=null;
  message=null;
  constructor(private formbuilder:FormBuilder,
    public taskService:TasksService,
    public notificationService:NotificationService,
    public dialogRef:MatDialogRef<TaskFormComponent>) { }

  ngOnInit() {
    
      this.taskService.getTasks();
  }
    
  
  onFormSubmit(){
  //added for submit to firebase db (added seperate brackets)
  if(this.taskService.form.valid){
    if(!this.taskService.form.get('$key').value){
    this.taskService.insertTaskList(this.taskService.form.value);
    this.taskService.form.reset();
    this.taskService.InitializeformGroup();
    this.notificationService.success(':: Created Successfully');
    this.onClose();
    }
    else
    {
    this.taskService.updateTaskList(this.taskService.form.value);
    this.taskService.form.reset();
    this.taskService.InitializeformGroup();
    this.notificationService.success(':: Updated Successfully');
    this.onClose();
  }
}
  }
  
    resetForm(){
      this.taskService.form.reset();
      this.taskService.InitializeformGroup();
      this.notificationService.warn(':: cleared form Successfully');
  
      this.message=null;
      this.dataSaved=false;
    }
    //added
    onClose(){
      this.taskService.form.reset();
      this.taskService.InitializeformGroup();
      this.dialogRef.close();
    }
}
