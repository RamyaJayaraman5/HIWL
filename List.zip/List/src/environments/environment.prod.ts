export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyD3SWlbh0TbQYQdEYqzuVPGg_u5eL96YAc",
    authDomain: "homeimprovementwishlist.firebaseapp.com",
    databaseURL: "https://homeimprovementwishlist.firebaseio.com",
    projectId: "homeimprovementwishlist",
    storageBucket: "",
    messagingSenderId: "131092304389",
    appId: "1:131092304389:web:5e489e0f8f0d3be8"
  }
};
