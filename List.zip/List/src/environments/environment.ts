export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyD3SWlbh0TbQYQdEYqzuVPGg_u5eL96YAc",
    authDomain: "homeimprovementwishlist.firebaseapp.com",
    databaseURL: "https://homeimprovementwishlist.firebaseio.com",
    projectId: "homeimprovementwishlist",
    storageBucket: "",
    messagingSenderId: "131092304389",
    appId: "1:131092304389:web:5e489e0f8f0d3be8"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
